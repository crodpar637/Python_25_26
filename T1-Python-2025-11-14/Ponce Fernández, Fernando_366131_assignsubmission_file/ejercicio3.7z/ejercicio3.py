
def cargar_reserva_desde():

    dic ={}
    with open(nombre_fichero,"r",newline="")as f:
        for linea in f:
            
            dic

        completo = 