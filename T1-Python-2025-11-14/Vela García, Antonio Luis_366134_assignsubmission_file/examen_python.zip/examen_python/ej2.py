def leer_ventas_tapas():
    nombre_tapa = input("Introduce un nombre de una tapa: ")
    precio_unitario = input("Introduce un precio: ")
    cantidad_vendida = input("Introduce una cantidad vendida: ")
